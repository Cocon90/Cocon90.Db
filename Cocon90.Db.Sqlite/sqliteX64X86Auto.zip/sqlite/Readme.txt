﻿readme about this sqlite folder:
	
	x64: the sqlite lib for 64 bit pc.
	x86: the sqlite lib for 86 bit pc.
	Auto: the sqlite lib auto release x86 or x64 version for the pc.

	this sqlite dll have a special place, it not depends vc++ runtime.

